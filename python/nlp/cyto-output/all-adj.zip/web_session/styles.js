var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "height" : 50.0,
      "shape" : "ellipse",
      "border-opacity" : 1.0,
      "text-opacity" : 1.0,
      "border-width" : 10.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(255,247,243)",
      "width" : 50.0,
      "border-color" : "rgb(51,153,255)",
      "font-size" : 8,
      "background-opacity" : 1.0,
      "background-color" : "rgb(122,1,119)",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[ id = '6976' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "rectangle",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node[ id = '6244' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "hexagon",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node[ id = '5901' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "hexagon",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node[ id = '2065' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "hexagon",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node[ id = '6329' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "rectangle",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node[ id = '3102' ]",
    "css" : {
      "width" : 150.0,
      "height" : 150.0,
      "shape" : "hexagon",
      "font-size" : 14,
      "background-color" : "rgb(197,27,125)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-style" : "solid",
      "content" : "",
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(51,153,255)",
      "opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "width" : 3.0,
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]